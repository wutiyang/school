<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta http-equiv='content-type' content='text/html;charset=utf-8' />
	<title>SchoolCMS学校管理系统 - Powered by SchoolCMS</title>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/jquery.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/common.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/My97DatePicker/WdatePicker.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Common/common.css" />
	<script type="text/javascript" src="__ROOT__/Static/Js/Admin/basicsettingsindex.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Admin/basicsettingsindex.css" />
	<script type='text/javascript' >
		var SITE_PATH = '<?php echo ($SITE_ROOT); ?>';  //定义项目所在绝对地址
		var tplroot = '__ROOT__/admin.php';  //定义js变量（项目根目录）
		var root = '__ROOT__';  //定义js变量（网站根目录）
	</script>
</head>
<body>
<div id="basicsettingsindex">
	<form action="./Index" method="post" return false>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td><?php echo ($semester); ?></td>
				<td class="tds">学期分类必须设置、先到 分类管理>学期分类管理 页面新增</td>
			</tr>
			<tr>
				<td><?php echo ($modelcsv); ?></td>
				<td class="tds">如果您CSV导出数据是乱码的情况下、在这里换一个编码即可</td>
			</tr>
			<tr>
				<td><?php echo ($modelpage); ?></td>
				<td class="tds">后台分页显示参数配置</td>
			</tr>
			<tr>
				<td><?php echo ($studentpage); ?></td>
				<td class="tds">学员管理页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($achievementpage); ?></td>
				<td class="tds">学员管理>学员成绩管理页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($teacherpage); ?></td>
				<td class="tds">教师管理页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($teachercurriculumpage); ?></td>
				<td class="tds">教师管理>教师课程管理页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($financepage); ?></td>
				<td class="tds">财务管理>缴费管理页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($financialdetailspage); ?></td>
				<td class="tds">财务管理>缴费明细页面、数据显示条数、如果为0 则使用系统默认:8条</td>
			</tr>
			<tr>
				<td><?php echo ($poor); echo ($cypoor); echo ($medium); echo ($good); echo ($excellent); ?></td>
				<td class="tds">输入1至3位的纯数字、成绩类型的最大值、如果为0，则使用系统默认:(20:差，40:较差，60:中，80:良，100:优[不封顶])</td>
			</tr>
			
		</table>
		<input type="submit" class="adminsubmit" id="submit" name="submit" title="提交" value="提交" />
	</form>
</div>
</body>
</html>