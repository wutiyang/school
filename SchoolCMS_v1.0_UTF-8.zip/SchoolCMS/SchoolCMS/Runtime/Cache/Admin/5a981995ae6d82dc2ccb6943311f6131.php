<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta http-equiv='content-type' content='text/html;charset=utf-8' />
	<title>SchoolCMS学校管理系统 - Powered by SchoolCMS</title>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/jquery.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/common.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/My97DatePicker/WdatePicker.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Common/common.css" />
	<script type="text/javascript" src="__ROOT__/Static/Js/Admin/studentinterface.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Admin/studentinterface.css" />
	<script type='text/javascript' >
		var SITE_PATH = '<?php echo ($SITE_ROOT); ?>';  //定义项目所在绝对地址
		var tplroot = '__ROOT__/admin.php';  //定义js变量（项目根目录）
		var root = '__ROOT__';  //定义js变量（网站根目录）
	</script>
</head>
<body>
<div id="studentinterface">
	<form action="<?php echo ($url); ?>" method="post" return false>
		<table>
			<tr>
				<td><?php echo ($srid); ?></td>
				<td><?php echo ($sname); ?></td>
			</tr>
			<tr>
				<td><?php echo ($smobile); ?></td>
				<td><?php echo ($shomephone); ?></td>
			</tr>
			<tr>
				<td><?php echo ($sbirthdate); ?></td>
				<td><?php echo ($ssex); ?></td>
			</tr>
			<tr>
				<td><?php echo ($cyid); ?></td>
				<td><?php echo ($cid); ?></td>
			</tr>
			<tr>
				<td><?php echo ($seffectivetime); ?></td>
				<td><?php echo ($stheendtime); ?></td>
			</tr>
			<tr id="studentformdisplay">
				<td><?php echo ($ptmoney); ?></td>
				<td><?php echo ($ptremarks); ?></td>
			</tr>
		</table>
		<input type="hidden" name="sid" value="<?php echo ($sid); ?>" />
		<input type="hidden" id="studentformtype" value="<?php echo ($type); ?>" />
		<input type="submit" class="adminsubmit" id="submit" name="submit" title="提交" value="提交" />
	</form>
</div>
</body>
</html>