<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta http-equiv='content-type' content='text/html;charset=utf-8'>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Common/common.css" />
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Admin/welcome.css" />
</head>
<body>
<div class="welcome">
	<div id="home_toptip"></div>
	<h2 class="h_a">系统信息</h2>
	<div class="home_info">
		<ul>
			<li>
				<em>软件版本</em>
				<span>
					<?php echo ($version); ?>
					<a href="http://www.schoolcms.cn/" target="_blank" class="schoolcmsnew">查看最新版本</a>
				</span>
			</li>
			<li>
				<em>操作系统</em>
				<span><?php echo ($localhostversion); ?></span>
			</li>
			<li>
				<em>PHP版本</em>
				<span><?php echo ($phpversion); ?></span>
			</li>
			<li>
				<em>MYSQL版本</em>
				<span><?php echo ($mysqlversion); ?></span>
			</li>
			<li>
				<em>服务器端信息</em>
				<span><?php echo ($webversion); ?></span>
			</li>
			<li>
				<em>当前域名</em>
				<span><?php echo ($urlversion); ?></span>
			</li>
		</ul>
	</div>
	<h2 class="h_a">开发团队</h2>
	<div class="home_info" id="home_devteam">
		<ul>
			<li>
				<em>版权所有</em>
				<span>www.schoolcms.cn</span>
			</li>
			<li>
				<em>负责人</em>
				<span>龚福祥</span>
			</li>
			<li>
				<em>产品研发</em>
				<span>李林、郭超、谢伟、司明侠、李中俊、吴志勇、武泽东、饶立宝、高建成、李楠、江小文</span>
			</li>
			<li>
				<em>UED</em>
				<span>晏方园、秦大兰</span>
			</li>
			<li>
				<em>市场运营</em>
				<span>柳庆春、周雪清</span>
			</li>
		</ul>
	</div>
</div>
</body>
</html>