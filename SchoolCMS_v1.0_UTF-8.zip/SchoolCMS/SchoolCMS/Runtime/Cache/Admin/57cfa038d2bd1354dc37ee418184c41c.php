<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta http-equiv='content-type' content='text/html;charset=utf-8' />
	<title>SchoolCMS学校管理系统 - Powered by SchoolCMS</title>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/jquery.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/common.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Common/common.css" />
	<script type='text/javascript' >
		var SITE_PATH = '<?php echo ($SITE_ROOT); ?>';  //定义项目所在绝对地址
		var tplroot = '__ROOT__/admin.php';  //定义js变量（项目根目录）
		var root = '__ROOT__';  //定义js变量（网站根目录）
		var windowheight = $(window).height()-91;
	</script>
</head>
<body>
<?php echo ($achievementclass); ?>
</form>
</body>
</html>