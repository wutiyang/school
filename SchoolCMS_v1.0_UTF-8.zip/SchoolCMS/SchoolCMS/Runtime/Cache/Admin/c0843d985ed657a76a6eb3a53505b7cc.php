<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta http-equiv='content-type' content='text/html;charset=utf-8' />
	<title>SchoolCMS学校管理系统 - Powered by SchoolCMS</title>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/jquery.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/common.js"></script>
	<script type="text/javascript" src="__ROOT__/Static/Js/Common/My97DatePicker/WdatePicker.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Common/common.css" />
	<script type="text/javascript" src="__ROOT__/Static/Js/Admin/studentmanagement.js"></script>
	<link rel="stylesheet" type="text/css" href="__ROOT__/Static/Css/Admin/studentmanagement.css" />
	<script type='text/javascript' >
		var SITE_PATH = '<?php echo ($SITE_ROOT); ?>';  //定义项目所在绝对地址
		var tplroot = '__ROOT__/admin.php';  //定义js变量（项目根目录）
		var root = '__ROOT__';  //定义js变量（网站根目录）
	</script>
</head>
<body>
<div id="studentmanagement">
	<div id="studentmanagementtop">
		<form action="./StudentManagement" method="post" return false>
			<table>
				<tr>
					<td>
						<?php echo ($sname); ?>
					</td>
					<td>
						<?php echo ($cid); ?>
					</td>
					<td>
						<?php echo ($stuitionstatu); ?>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo ($ssex); ?>
					</td>
					<td>
						<?php echo ($sage); echo ($sages); ?>
					</td>
					<td>
						<?php echo ($ssreatedate); ?>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo ($cyid); ?>
					</td>
					<td>
						<?php echo ($sbirthdate); ?>
					</td>
					<td>
						<?php echo ($seffectivetime); ?>
					</td>
				</tr>
				
			</table>
			<div id="submit">
				<a href="./StudentManagement" title="撤销">
					<span class="adminsubmits adminsubpd">撤销</span>
				</a>
				<br />
				<input type="submit" class="adminsubmit" id="submits" title="查询" value="查询" />
			</div>
		</form>
	</div>
	<div id="tablecontent">
		<form action="./Index" method="post" return false>
			<?php echo ($gridtable); ?>
			<div class="tablecontentsub">
				<input type="submit" class="adminsubmits" name="submitdelete" id="submitdelete" title="删除"  value="删除" />
				<a href="StudentAddInfo" title="新增学员">
					<span class="adminsubmit studentaddsub adminsubpd">新增学员</span>
				</a>
				<span class="adminsubmit studentaddsub adminsubpd" id="subcsvexport" title="导出CSV文件">导出CSV</span>
			</div>
			<div class="tablecontentpage"><?php echo ($pageing); ?></div>
		</form>
	</div>
	<!-- CSV代码 --><?php echo ($subcsvexport); ?>
	
</div>
</body>
</html>