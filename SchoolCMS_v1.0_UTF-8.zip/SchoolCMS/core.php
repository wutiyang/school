<?php

define('APP_DEBUG', true);
define('SITE_PATH', dirname(__FILE__));
define('THINK_PATH', SITE_PATH.'/ThinkPHP/');

