<?php

header('Content-Type:text/html; charset=UTF-8');

require './core.php';
define("APP_NAME","back");
define('APP_PATH', SITE_PATH.'/SchoolCMS/');
require THINK_PATH.'ThinkPHP.php';